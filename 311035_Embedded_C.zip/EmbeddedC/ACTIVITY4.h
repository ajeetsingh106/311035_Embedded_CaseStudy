#ifndef ACTIVITY4_H_INCLUDED
#define ACTIVITY4_H_INCLUDED
void InitUSART(uint16_t);
char Readchar();
void Writechar(char);



#endif // ACTIVITY4_H_INCLUDED
