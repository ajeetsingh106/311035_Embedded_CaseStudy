#ifndef ACTIVITY3_H_INCLUDED
#define ACTIVITY3_H_INCLUDED
void pwmperipherals();
char output (uint16_t ADCvalue);


#endif // ACTIVITY3_H_INCLUDED
