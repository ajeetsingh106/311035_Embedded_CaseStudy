#ifndef ACTIVITY2_H_INCLUDED
#define ACTIVITY2_H_INCLUDED

void InitADC();
uint16_t ReadADC(uint16_t ch);




#endif // ACTIVITY2_H_INCLUDED
